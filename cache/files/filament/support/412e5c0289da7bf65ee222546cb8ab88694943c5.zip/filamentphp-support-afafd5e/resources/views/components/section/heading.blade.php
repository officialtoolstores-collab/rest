<h3
    {{ $attributes->class(['fi-section-header-heading text-base font-semibold leading-6 text-gray-950 dark:text-white']) }}
>
    {{ $slot }}
</h3>

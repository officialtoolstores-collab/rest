<?php

return [

    'distinct' => [
        'must_be_selected' => 'Առնվազն մեկ :attribute դաշտ պետք է ընտրվի։',
        'only_one_must_be_selected' => 'Պետք է ընտրվի միայն մեկ :attribute դաշտ։',
    ],

];

<?php

return [

    'trigger' => [
        'label' => 'Действия',
    ],

];

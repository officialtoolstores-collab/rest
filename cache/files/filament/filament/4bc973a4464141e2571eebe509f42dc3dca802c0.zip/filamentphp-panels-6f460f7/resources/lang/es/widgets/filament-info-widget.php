<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Documentación',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];

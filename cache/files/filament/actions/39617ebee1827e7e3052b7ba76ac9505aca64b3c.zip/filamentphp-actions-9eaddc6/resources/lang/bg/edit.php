<?php

return [

    'single' => [

        'label' => 'Редакция',

        'modal' => [

            'heading' => 'Редактиране :label',

            'actions' => [

                'save' => [
                    'label' => 'Запазване',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'Запазено',
            ],

        ],

    ],

];

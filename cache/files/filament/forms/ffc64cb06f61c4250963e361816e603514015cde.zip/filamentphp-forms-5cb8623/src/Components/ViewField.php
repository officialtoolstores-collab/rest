<?php

namespace Filament\Forms\Components;

class ViewField extends Field {}

<?php

return [

    'title' => ':label 보기',

    'breadcrumb' => '보기',

    'content' => [

        'tab' => [
            'label' => '보기',
        ],

    ],

];

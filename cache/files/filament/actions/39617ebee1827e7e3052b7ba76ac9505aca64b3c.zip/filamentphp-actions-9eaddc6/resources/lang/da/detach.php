<?php

return [

    'single' => [

        'label' => 'Frigør',

        'modal' => [

            'heading' => 'Frigør :label',

            'actions' => [

                'detach' => [
                    'label' => 'Frigør',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Frigjort',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Frigør valgte',

        'modal' => [

            'heading' => 'Frigør valgte :label',

            'actions' => [

                'detach' => [
                    'label' => 'Frigør',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Frigjort',
            ],

        ],

    ],

];

<?php

return [

    'messages' => [
        'copied' => '已複製',
    ],

];

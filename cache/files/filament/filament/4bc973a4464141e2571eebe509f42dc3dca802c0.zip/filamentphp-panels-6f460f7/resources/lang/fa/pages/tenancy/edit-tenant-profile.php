<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'ذخیره تغییرات',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'ذخیره شد',
        ],

    ],

];

<?php

return [

    'distinct' => [
        'must_be_selected' => ':attribute 필드 중 하나 이상을 선택해야 합니다.',
        'only_one_must_be_selected' => ':attribute 필드 중 하나만 선택해야 합니다.',
    ],

];

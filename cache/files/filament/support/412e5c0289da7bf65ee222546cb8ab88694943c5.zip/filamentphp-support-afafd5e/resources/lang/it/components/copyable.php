<?php

return [

    'messages' => [
        'copied' => 'Copiato',
    ],

];

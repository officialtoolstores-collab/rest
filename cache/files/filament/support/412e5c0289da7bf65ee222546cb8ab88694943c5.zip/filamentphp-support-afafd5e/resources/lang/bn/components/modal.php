<?php

return [

    'actions' => [

        'close' => [
            'label' => 'বন্ধ করুন',
        ],

    ],

];

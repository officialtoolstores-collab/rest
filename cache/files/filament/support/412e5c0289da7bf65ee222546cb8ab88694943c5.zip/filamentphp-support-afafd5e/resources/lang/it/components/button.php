<?php

return [

    'messages' => [

        'uploading_file' => 'Caricamento file...',

    ],

];

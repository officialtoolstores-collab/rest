<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Speichern',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Gespeichert',
        ],

    ],

];

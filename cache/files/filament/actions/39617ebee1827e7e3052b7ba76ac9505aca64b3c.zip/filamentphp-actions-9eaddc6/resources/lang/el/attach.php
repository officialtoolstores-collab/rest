<?php

return [

    'single' => [

        'label' => 'Attach',

        'modal' => [

            'heading' => 'Attach :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Record',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Attach',
                ],

                'attach_another' => [
                    'label' => 'Attach & attach another',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Attached',
            ],

        ],

    ],

];

<?php

return [

    'messages' => [
        'uploading_file' => 'Uploader fil...',
    ],

];

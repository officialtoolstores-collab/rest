<?php

return [

    'title' => 'Veure :label',

    'breadcrumb' => 'Veure',

    'content' => [

        'tab' => [
            'label' => 'Veure',
        ],

    ],

];

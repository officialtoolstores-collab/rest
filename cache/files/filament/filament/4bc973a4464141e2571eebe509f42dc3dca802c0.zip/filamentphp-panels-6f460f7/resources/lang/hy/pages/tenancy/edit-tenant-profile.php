<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Պահպանել փոփոխությունները',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Պահպանված է',
        ],

    ],

];

<?php

return [

    'body' => 'Sinulla on tallentamattomia muutoksia. Oletko varma että haluat poistua?',

];

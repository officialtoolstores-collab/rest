<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Kapat',
        ],

    ],

];

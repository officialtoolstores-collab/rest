<?php

return [

    'single' => [

        'label' => 'Créer',

        'modal' => [

            'heading' => 'Créer :label',

            'actions' => [

                'create' => [
                    'label' => 'Créer',
                ],

                'create_another' => [
                    'label' => 'Créer & Ajouter un autre',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Créé(e)',
            ],

        ],

    ],

];

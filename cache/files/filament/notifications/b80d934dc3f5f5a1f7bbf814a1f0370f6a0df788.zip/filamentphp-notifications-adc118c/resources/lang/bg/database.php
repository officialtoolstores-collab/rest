<?php

return [

    'modal' => [

        'heading' => 'Известия',

        'actions' => [

            'clear' => [
                'label' => 'Изчисти',
            ],

            'mark_all_as_read' => [
                'label' => 'Маркирай всички като прочетени',
            ],

        ],

        'empty' => [
            'heading' => 'Нямате известия',
            'description' => 'Моля проверете отново по-късно.',
        ],

    ],

];

<?php

namespace OpenAI\Testing\Responses\Fixtures\Responses;

final class DeleteResponseFixture
{
    public const ATTRIBUTES = [
        'id' => 'resp_67ccf18ef5fc8190b16dbee19bc54e5f087bb177ab789d5c',
        'object' => 'response',
        'deleted' => true,
    ];
}

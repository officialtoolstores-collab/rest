<?php

return [

    'distinct' => [
        'must_be_selected' => 'Najmanje jedan :attribute mora biti odabran.',
        'only_one_must_be_selected' => 'Samo jedan :attribute može biti odabrab.',
    ],

];

<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Хаах',
        ],

    ],

];

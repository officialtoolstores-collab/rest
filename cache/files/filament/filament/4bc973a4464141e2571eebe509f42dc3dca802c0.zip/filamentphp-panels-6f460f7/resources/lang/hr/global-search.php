<?php

return [

    'field' => [
        'label' => 'Globalno pretraživanje',
        'placeholder' => 'Pretraži',
    ],

    'no_results_message' => 'Nema pronađenih rezultata pretraživanja.',

];

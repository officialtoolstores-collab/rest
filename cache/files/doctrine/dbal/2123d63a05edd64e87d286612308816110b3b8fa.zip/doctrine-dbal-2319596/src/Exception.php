<?php

declare(strict_types=1);

namespace Doctrine\DBAL;

use Throwable;

interface Exception extends Throwable
{
}

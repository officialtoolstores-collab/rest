<?php

return [
    // Prefix used for all wallet transaction numbers
    'transaction_prefix' => env('WALLET_TXN_PREFIX', 'TXN-'),
];

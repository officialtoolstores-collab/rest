<?php

return [

    'single' => [

        'label' => 'Duplikat data',

        'modal' => [

            'heading' => 'Duplikat :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Duplikat data',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Data berhasil diduplikat',
            ],

        ],

    ],

];

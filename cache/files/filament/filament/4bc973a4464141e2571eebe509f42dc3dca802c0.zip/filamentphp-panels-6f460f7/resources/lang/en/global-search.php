<?php

return [

    'field' => [
        'label' => 'Global search',
        'placeholder' => 'Search',
    ],

    'no_results_message' => 'No search results found.',

];
